import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import Select from 'react-select'
import { API_BASE_URL } from '../../../config'
import {
  DspToastMessage,
  dspstatusv1,
  getAuthHeaders,
  IsVendorLoginIsValid,
} from '../../../utils/operation'
import FilePreview from '../../widgets/FilePreview'
import {
  getFileNameFromUrl,
  getCurrentLoggedUserID,
  YouTubeEmbed,
  GoogleMapEmbed,
} from '../../../utils/operation'
import { CRow, CCol } from '@coreui/react'
import moneyv1 from '../../../assets/images/moneyv1.png'
import ReactPlayer from 'react-player'

// 🔤 i18n packs (keeps English as fallback for any missing keys)
import enPack from '../../../i18n/enloc100.json'
import arPack from '../../../i18n/arloc100.json'

const Vendor = () => {
  // ✅ Toggle to hide "Student Range From" and "Student Range To"
  const HIDE_PRICE_RANGE_UI = true

  // ✅ Vendor login guard: runs once when this page mounts
  useEffect(() => {
    IsVendorLoginIsValid() // will redirect to BaseURL if token/usertype invalid
  }, [])

  // ---- i18n helpers (non-destructive) ----
  const getStoredLang = () => {
    try {
      const v = localStorage.getItem('heroz_lang')
      return v === 'ar' || v === 'en' ? v : 'ar'
    } catch {
      return 'ar'
    }
  }
  const [lang, setLang] = useState(getStoredLang())
  const dict = lang === 'ar' ? arPack : enPack
  const tr = (key, fallback) => (dict && dict[key]) || fallback
  const dayLabel = (d) => tr(`day_${d}`, d)
  useEffect(() => {
    const onChange = () => setLang(getStoredLang())
    window.addEventListener('heroz_lang_changed', onChange)
    return () => window.removeEventListener('heroz_lang_changed', onChange)
  }, [])
  // ----------------------------------------

  const [error, setError] = useState('')
  const [txtactImageName1, setactImageName1] = useState(null)
  const [txtactImageName2, setactImageName2] = useState(null)
  const [txtactImageName3, setactImageName3] = useState(null)
  const [ActivityData, setActivity] = useState(null)

  const navigate = useNavigate()
  const [fetchedCategories, setFetchedCategories] = useState([])

  const [loading, setLoading] = useState(false)
  const [toastMessage, setToastMessage] = useState('')
  const [toastType, setToastType] = useState('info')

  // -------------------- SUMMARY VALUES (VAT INCLUDED - DO NOT ADD VAT) --------------------
  // ✅ IMPORTANT: All prices returned from API are already VAT included.
  // ✅ Do not add VAT again and do not show VAT badges/columns.
  const priceList = ActivityData?.priceList || []
  const foodList = ActivityData?.foodList || []

  // ⭐ Standard money rounding (2.447 → 2.45, etc.)
  const to2 = (v) => {
    const n = Number(v || 0)
    if (!Number.isFinite(n)) return '0.00'
    return (Math.round((n + Number.EPSILON) * 100) / 100).toFixed(2)
  }

  // Trip price: first price row (already VAT included)
  const tripPriceBase = priceList.length > 0 ? Number(priceList[0].Price || 0) : 0

  // Extra price: sum of non-included extras only (already VAT included)
  const foodBaseAmount = foodList.reduce(
    (sum, item) => sum + (item.Include ? 0 : Number(item.FoodPrice || 0)),
    0,
  )

  // ✅ Final total = Trip + Extra only. VAT is already included in each price.
  const totalBaseAmount = tripPriceBase + foodBaseAmount
  // -------------------------------------------------------------------------

  const fetchActivity = async (ActivityIDVal) => {
    setLoading(true)
    try {
      const response = await fetch(
        `${API_BASE_URL}/vendordata/activityinfo/activity/getActivity`,
        {
          method: 'POST',
          headers: getAuthHeaders(),
          body: JSON.stringify({
            ActivityID: ActivityIDVal,
            VendorID: getCurrentLoggedUserID(),
          }),
        },
      )

      if (!response.ok) throw new Error('Failed to fetch activities')

      const data = await response.json()
      setActivity(data.data || [])
      setTotalPages(Math.ceil(data.totalCount / ActivityPerPage))
    } catch (error) {
      setError(tr('errFetchActivities', 'Error fetching activities'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (!ActivityData) return

    // Basic info
    setactImageName1(ActivityData.actImageName1Url || '')
    setactImageName2(ActivityData.actImageName2Url || '')
    setactImageName3(ActivityData.actImageName3Url || '')
  }, [ActivityData])

  useEffect(() => {
    // 👇 Extract ActivityID from the URL
    const getSearchParams = () => {
      const search =
        window.location.search ||
        (window.location.hash && window.location.hash.includes('?')
          ? `?${window.location.hash.split('?')[1]}`
          : '')
      return new URLSearchParams(search)
    }

    const urlParams = getSearchParams()
    const ActivityIDVal = urlParams.get('ActivityID')

    if (ActivityIDVal) {
      fetchActivity(ActivityIDVal)
    } else {
      setError(tr('errActivityIdMissing', 'ActivityID is missing in URL'))
    }
  }, [])

  return (
    <div>
      <div className="msgbox" style={{ marginBottom: '20px', marginTop: '20px' }}>
        <div className="form-group text-center">
          <div style={{ padding: '20px' }}>
            <b>{tr('labelActivityStatus', 'ACTIVITY STATUS :')}</b>{' '}
            {dspstatusv1(ActivityData?.actStatus)}
          </div>
        </div>
      </div>
      <div className="divhbg">
        {/* Left side: Title */}
        <div className="txtheadertitle">{tr('viewActivityTitle', 'View Activity')}</div>

        {/* Right side: Buttons */}
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button
            type="button"
            className="admin-buttonv1"
            onClick={() => navigate('/vendordata/activityinfo/activity/list?')}
          >
            {tr('btnReturn', 'Return')}
          </button>
        </div>
      </div>

      <div className="txtsubtitle">
        {tr('sectionActivityInfo', 'Activity Information')}
      </div>

      <div className="divbox">
        <div className="form-group">
          <label style={{ marginBottom: '10px', marginTop: '20px' }}>
            {tr('labelActivityName', 'Activity Name')}
          </label>
          <div className="admin-lbl-box"> {ActivityData?.actName} </div>
        </div>

        <div className="form-group">
          <label style={{ marginBottom: '10px', marginTop: '20px' }}>
            {tr('labelActivityType', 'Activity Type')}
          </label>
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
            <div className="admin-lbl-box"> {ActivityData?.actTypeID} </div>
          </div>
        </div>

        <div style={{ marginBottom: '10px', marginTop: '20px' }}>
          <label style={{ display: 'block', fontWeight: 'bold', marginBottom: 8 }}>
            {tr('labelCategories', 'Activity Categories')}
          </label>

          <div>
            {ActivityData?.categoryInfo?.map((cat, index) => (
              <span key={index} className="admin-lbl-box pink-badge">
                {cat.EnCategoryName}
              </span>
            ))}
          </div>
        </div>

        <div className="form-group">
          <label>{tr('labelActivityDesc', 'Activity Description')}</label>
          <div className="admin-lbl-boxv1"> {ActivityData?.actDesc} </div>
        </div>
      </div>

      <div className="txtsubtitle">
        {tr('sectionActivityImages', 'Activity Images')}{' '}
      </div>
      <div className="divbox">
        <div
          style={{
            display: 'flex',
            gap: '20px',
            flexWrap: 'wrap',
            marginTop: '20px',
            marginBottom: '20px',
          }}
        >
          {/* Image 1 */}
          <div className="form-group" style={{ flex: '1' }}>
            <label>{tr('labelImage1', 'Activity Image 1')}</label>
            <FilePreview file={txtactImageName1} />
          </div>

          {/* Image 2 */}
          <div className="form-group" style={{ flex: '1' }}>
            <label>{tr('labelImage2', 'Activity Image 2')}</label>
            <FilePreview file={txtactImageName2} />
          </div>

          {/* Image 3 */}
          <div className="form-group" style={{ flex: '1' }}>
            <label>{tr('labelImage3', 'Activity Image 3')}</label>
            <FilePreview file={txtactImageName3} />
          </div>
        </div>
      </div>

      <div className="txtsubtitle">
        {tr('sectionYouTube', 'Activity Youtube Videos')}{' '}
      </div>
      <div className="divbox">
        <div
          style={{
            display: 'flex',
            gap: '20px',
            flexWrap: 'wrap',
            marginTop: '20px',
            marginBottom: '20px',
          }}
        >
          {/* Video 1 */}
          <div className="form-group" style={{ flex: '1' }}>
            <label>{tr('labelYouTube1', 'Youtube Video Link 1')}</label>
            <YouTubeEmbed videoId={ActivityData?.actYouTubeID1} />
          </div>

          {/* Video 2 */}
          <div className="form-group" style={{ flex: '1' }}>
            <label>{tr('labelYouTube2', 'Youtube Video Link 2')}</label>
            <div>
              <YouTubeEmbed videoId={ActivityData?.actYouTubeID2} />
            </div>
          </div>

          {/* Video 3 */}
          <div className="form-group" style={{ flex: '1' }}>
            <label>{tr('labelYouTube3', 'Youtube Video Link 3')}</label>
            <div>
              <YouTubeEmbed videoId={ActivityData?.actYouTubeID3} />
            </div>
          </div>
        </div>
      </div>

      <div className="txtsubtitle">
        {tr('sectionLocation', 'Activity Location')}{' '}
      </div>

      <div className="divbox">
        <div className="vendor-container">
          <div className="vendor-row">
            <div className="vendor-column">
              <label className="vendor-label">
                {tr('labelGoogleMap', 'Google Map Location')}
              </label>

              <iframe
                width="100%"
                height="300"
                frameBorder="0"
                style={{ border: 0 }}
                referrerPolicy="no-referrer-when-downgrade"
                src={`https://www.google.com/maps/embed/v1/view?key=AIzaSyC59f-F3JungvspyPlTLlQa90DQ2aQAhRo&center=${
                  ActivityData?.actGlat || 39.2111492
                },${ActivityData?.actGlan || 21.4552355}&zoom=15`}
                allowFullScreen
                title="Google Map"
              />
            </div>
          </div>

          <div className="vendor-row">
            <div className="vendor-column">
              <label className="vendor-label">
                {tr('labelLatitude', 'Google Latitude')}
              </label>
              <div className="admin-lbl-box"> {ActivityData?.actGlat} </div>
            </div>
            <div className="vendor-column">
              <label className="vendor-label">
                {tr('labelLongitude', 'Google Longitude')}
              </label>
              <div className="admin-lbl-box"> {ActivityData?.actGlan} </div>
            </div>
          </div>
        </div>
      </div>

      <div className="divbox">
        <div className="vendor-container">
          <div className="vendor-row">
            <div className="vendor-column">
              <label className="vendor-label">{tr('labelCountry', 'Country')}</label>
              <div className="admin-lbl-box"> {ActivityData?.EnCountryName} </div>
            </div>

            <div className="vendor-column">
              <label className="vendor-label">{tr('labelCity', 'City')}</label>
              <div className="admin-lbl-box"> {ActivityData?.EnCityName} </div>
            </div>
            <div className="vendor-column">
              <label className="vendor-label">
                {tr('labelLocation1', 'Address1')}
              </label>
              <div className="admin-lbl-box"> {ActivityData?.actAddress1} </div>
            </div>
            <div className="vendor-column">
              <label className="vendor-label">
                {tr('labelAddress2', 'Address2')}
              </label>
              <div className="admin-lbl-box"> {ActivityData?.actAddress2} </div>
            </div>
          </div>
        </div>
      </div>

      <div className="txtsubtitle">
        {tr('sectionAgeRange', ' Age Range ')}
      </div>
      <div className="divbox">
        {/* // row start */}
        <div className="vendor-container">
          <div className="vendor-row" style={{ display: 'flex', gap: '20px' }}>
            <div
              className="vendor-column"
              style={{ flex: 1, display: 'flex', flexDirection: 'column' }}
            >
              <label className="vendor-label">
                {tr('labelMinAge', 'Minimum Age')}
              </label>

              <div className="admin-lbl-box"> {ActivityData?.actMinAge} </div>
            </div>

            <div
              className="vendor-column"
              style={{ flex: 1, display: 'flex', flexDirection: 'column' }}
            >
              <label className="vendor-label">
                {tr('labelMaxAge', 'Maximum Age')}
              </label>
              <div className="admin-lbl-box"> {ActivityData?.actMaxAge} </div>
            </div>
          </div>
        </div>
        {/* // row end */}

        {/* // row start */}
        <div className="vendor-container">
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
            <label className="vendor-label">{tr('labelGender', 'Gender')}</label>
            <label style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
              <div className="admin-lbl-box pink-badge"> {ActivityData?.actGender} </div>
            </label>
          </div>
        </div>
        {/* // row end */}
      </div>
      {/* // row end */}

      <div className="txtsubtitle">
        {tr('sectionCapacityInfo', 'Capacity Information ')}{' '}
      </div>
      <div className="divbox">
        {/* // row start */}
        <div className="vendor-container">
          <div className="vendor-row" style={{ display: 'flex', gap: '20px' }}>
            <div
              className="vendor-column"
              style={{ flex: 1, display: 'flex', flexDirection: 'column' }}
            >
              <label className="vendor-label">
                {tr('labelMinStudents', 'Minimum Students')}
              </label>
              <div className="admin-lbl-box"> {ActivityData?.actMinStudent} </div>
            </div>

            <div
              className="vendor-column"
              style={{ flex: 1, display: 'flex', flexDirection: 'column' }}
            >
              <label className="vendor-label">
                {tr('labelMaxStudents', 'Maximum Students')}
              </label>
              <div className="admin-lbl-box"> {ActivityData?.actMaxStudent} </div>
            </div>
          </div>
        </div>
        {/* // row end */}
      </div>

      <div className="txtsubtitle">
        {tr('sectionPricePerStudent', 'Price Per Student')}
      </div>

      <div className="divbox">
        {/* Table Header */}
        <CRow className="fw-bold  mb-2">
          <CCol sm={3}>{tr('colBasePricePerStudent', 'Price')}</CCol>
          <CCol sm={3} style={{ display: HIDE_PRICE_RANGE_UI ? 'none' : undefined }}>
            {tr('labelStudentRangeFrom', 'Student Range From')}
          </CCol>
          <CCol sm={3} style={{ display: HIDE_PRICE_RANGE_UI ? 'none' : undefined }}>
            {tr('labelStudentRangeTo', 'Student Range To')}
          </CCol>
          <CCol sm={3}></CCol> {/* Remove column */}
        </CRow>

        {/* Dynamic Form Rows */}
        {ActivityData?.priceList?.map((priceItem, index) => {
          return (
            <CRow className="align-items-center mb-2" key={index}>
              <CCol sm={12}>
                <div className="admin-lbl-box pink-shadow1 ">
                  <img
                    src={moneyv1}
                    alt="logo"
                    style={{ width: '14px', marginRight: '6px', verticalAlign: 'middle' }}
                  />
                  {to2(priceItem.Price)}
                </div>
              </CCol>
              <CCol sm={3} style={{ display: HIDE_PRICE_RANGE_UI ? 'none' : undefined }}>
                <div className="admin-lbl-box text-center pink-shadow2">
                  {priceItem.StudentRangeFrom}
                </div>
              </CCol>
              <CCol sm={3} style={{ display: HIDE_PRICE_RANGE_UI ? 'none' : undefined }}>
                <div className="admin-lbl-box text-center pink-shadow3">
                  {priceItem.StudentRangeTo}
                </div>
              </CCol>
            </CRow>
          )
        })}
      </div>

      <div className="txtsubtitle">
        {tr('sectionSetAvailability', 'Set Availability')}
      </div>
      <div className="divbox">
        <div style={{ margin: '20px auto', fontFamily: 'Arial, sans-serif' }}>
          {['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']
            .filter((day) => ActivityData?.availList?.some((item) => item.DayName === day))
            .map((day) => {
              const matchedEntries = ActivityData.availList.filter(
                (item) => item.DayName === day,
              )

              return (
                <div
                  key={day}
                  style={{
                    marginBottom: '30px',
                    padding: '20px',
                    borderBottom: '1px solid #ccc',
                    borderRadius: '10px',
                    backgroundColor: '#f9f9f9',
                  }}
                >
                  <label>
                    <div
                      className="admin-lbl-box pink-shadow1"
                      style={{ fontWeight: 'bold', textTransform: 'capitalize' }}
                    >
                      {dayLabel(day)} <input type="checkbox" checked readOnly />{' '}
                      {tr('labelAvailable', 'Available')}
                    </div>
                  </label>

                  <div style={{ marginTop: '10px' }}>
                    {/* Header row */}
                    <div
                      style={{
                        display: 'flex',
                        gap: 20,
                        alignItems: 'center',
                        flexWrap: 'wrap',
                        fontWeight: 'bold',
                        marginBottom: '8px',
                      }}
                    >
                      <div style={{ width: '200px', textAlign: 'center' }}>
                        {tr('labelStartTime', 'Start Time')}
                      </div>
                      <div style={{ width: '200px', textAlign: 'center' }}>
                        {tr('labelEndTime', 'End Time')}
                      </div>
                      <div style={{ width: '200px', textAlign: 'center' }}>
                        {tr('labelNotes', 'Note')}
                      </div>
                    </div>

                    {/* Data rows */}
                    {matchedEntries.map((slot, index) => (
                      <div
                        key={index}
                        style={{
                          display: 'flex',
                          gap: 20,
                          alignItems: 'center',
                          flexWrap: 'wrap',
                          marginBottom: '6px',
                        }}
                      >
                        <div
                          className="admin-lbl-boxv1"
                          style={{ width: '200px', textAlign: 'center' }}
                        >
                          {slot.StartTime || '--'}
                        </div>
                        <div
                          className="admin-lbl-boxv1"
                          style={{ width: '200px', textAlign: 'center' }}
                        >
                          {slot.EndTime || '--'}
                        </div>
                        <div
                          className="admin-lbl-boxv1"
                          style={{ width: '200px', textAlign: 'center' }}
                        >
                          {slot.Note || '--'}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}
        </div>
      </div>

      <div className="txtsubtitle">
        {tr('sectionFoodInfo', 'Extra Information')}
      </div>
      <div className="divbox">
        <div style={{ margin: '20px auto', fontFamily: 'Arial, sans-serif' }}>
          {/* Header Row */}
          <CRow className="mb-2 fw-bold hbg">
            <CCol sm={3}>{tr('colFoodName', 'Extra Name')}</CCol>
            <CCol sm={2}>
              {tr('colBaseFoodPrice', 'Extra Price')}
            </CCol>
            <CCol sm={3}>{tr('colNotes', 'Notes')}</CCol>
            <CCol sm={2}>{tr('colFoodImage', 'Extra Image')}</CCol>
            <CCol sm={1}>{tr('colInclude', 'Include')}</CCol>
            <CCol sm={1}></CCol> {/* For remove button */}
          </CRow>

          {ActivityData?.foodList?.map((foodItem, index) => {
            return (
              <CRow key={index} className="mb-3 align-items-center">
                {/* Extra Name */}
                <CCol sm={3}>
                  <div className="admin-lbl-box">{foodItem.FoodName}</div>
                </CCol>

                {/* Price + VAT pill + Total incl. VAT */}
                <CCol sm={2}>
                  <div className="admin-lbl-box text-center">
                    {to2(foodItem.FoodPrice)}
                  </div>
                </CCol>

                {/* Notes */}
                <CCol sm={3}>
                  <div className="admin-lbl-box text-center">
                    {foodItem.FoodNotes}
                  </div>
                </CCol>

                {/* Image Preview (optional handling for blank image) */}
                <CCol sm={2}>
                  {foodItem.FoodImage ? (
                    <FilePreview file={foodItem.FoodImage} />
                  ) : (
                    <div className="admin-lbl-box text-center">
                      {tr('noImage', 'No Image')}
                    </div>
                  )}
                </CCol>

                {/* Include (displayed as Yes/No or Boolean) */}
                <CCol sm={1} className="text-center">
                  <div className="admin-lbl-box text-center">
                    {foodItem.Include ? tr('yes', 'Yes') : tr('no', 'No')}
                  </div>
                </CCol>
              </CRow>
            )
          })}
        </div>
      </div>

      {/* -------------------- SUMMARY (BOTTOM, READ-ONLY) -------------------- */}
      <div className="txtsubtitle">
        {tr('sectionSummary', 'Summary')}
      </div>
      <div className="divbox">
        <div
          style={{
            maxWidth: 900,
            margin: '0 auto',
            border: '1px solid rgba(122, 0, 92, 0.14)',
            borderRadius: 18,
            overflow: 'hidden',
            background: 'linear-gradient(180deg, #ffffff 0%, #fff7fd 100%)',
            boxShadow: '0 12px 30px rgba(94, 0, 83, 0.10)',
            fontSize: 14,
          }}
        >
          <div
            style={{
              padding: '16px 18px',
              borderBottom: '1px solid rgba(122, 0, 92, 0.10)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: 12,
              flexWrap: 'wrap',
              background: 'linear-gradient(90deg, rgba(122,0,92,0.08), rgba(207,32,122,0.05))',
            }}
          >
            <div>
              <div style={{ fontSize: 18, fontWeight: 900, color: '#25001f' }}>
                {tr('sectionSummary', 'Summary')}
              </div>
              <div style={{ fontSize: 12, color: '#6b5566', marginTop: 3 }}>
                {tr('summaryVatIncludedNote', 'VAT is already included in the prices. No VAT is added again.')}
              </div>
            </div>
            <div
              style={{
                borderRadius: 999,
                padding: '7px 12px',
                fontSize: 12,
                fontWeight: 800,
                color: '#6f005d',
                background: 'rgba(122, 0, 92, 0.10)',
                border: '1px solid rgba(122, 0, 92, 0.16)',
              }}
            >
              {tr('summaryVatIncluded', 'VAT Included')}
            </div>
          </div>

          <div style={{ overflowX: 'auto' }}>
            <table
              style={{
                width: '100%',
                borderCollapse: 'separate',
                borderSpacing: 0,
                minWidth: 620,
              }}
            >
              <thead>
                <tr style={{ background: '#fff' }}>
                  <th style={{ textAlign: 'left', padding: '14px 16px', fontWeight: 900, color: '#1f1f1f' }}>
                    {tr('summaryDescription', 'Description')}
                  </th>
                  <th style={{ textAlign: 'right', padding: '14px 16px', fontWeight: 900, color: '#1f1f1f' }}>
                    {tr('summaryBasePrice', 'Base Price')}
                  </th>
                  <th style={{ textAlign: 'right', padding: '14px 16px', fontWeight: 900, color: '#1f1f1f' }}>
                    {tr('summaryTotal', 'Total')}
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style={{ padding: '14px 16px', borderTop: '1px solid #f0e4ee', fontWeight: 700 }}>
                    {tr('summaryTrip', 'Trip')}
                  </td>
                  <td style={{ padding: '14px 16px', borderTop: '1px solid #f0e4ee', textAlign: 'right', fontWeight: 700 }}>
                    {to2(tripPriceBase)}
                  </td>
                  <td style={{ padding: '14px 16px', borderTop: '1px solid #f0e4ee', textAlign: 'right', fontWeight: 900, color: '#25001f' }}>
                    {to2(tripPriceBase)}
                  </td>
                </tr>
                <tr style={{ background: 'rgba(122, 0, 92, 0.025)' }}>
                  <td style={{ padding: '14px 16px', borderTop: '1px solid #f0e4ee', fontWeight: 700 }}>
                    {tr('summaryExtra', 'Extra')}
                  </td>
                  <td style={{ padding: '14px 16px', borderTop: '1px solid #f0e4ee', textAlign: 'right', fontWeight: 700 }}>
                    {to2(foodBaseAmount)}
                  </td>
                  <td style={{ padding: '14px 16px', borderTop: '1px solid #f0e4ee', textAlign: 'right', fontWeight: 900, color: '#25001f' }}>
                    {to2(foodBaseAmount)}
                  </td>
                </tr>
                <tr>
                  <td style={{ padding: '16px', borderTop: '2px solid #ead4e6', fontWeight: 900, fontSize: 15 }}>
                    {tr('summaryTotal', 'Total')}
                  </td>
                  <td style={{ padding: '16px', borderTop: '2px solid #ead4e6', textAlign: 'right', fontWeight: 900, fontSize: 15 }}>
                    {to2(totalBaseAmount)}
                  </td>
                  <td style={{ padding: '16px', borderTop: '2px solid #ead4e6', textAlign: 'right' }}>
                    <span
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        minWidth: 110,
                        borderRadius: 999,
                        padding: '8px 14px',
                        background: 'linear-gradient(135deg, #5f0055, #cf207a)',
                        color: '#fff',
                        fontWeight: 900,
                        fontSize: 16,
                        boxShadow: '0 8px 18px rgba(122, 0, 92, 0.22)',
                      }}
                    >
                      {to2(totalBaseAmount)}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      {/* ----------------------------------------------------------- */}

      <div className="txtsubtitle">{tr('sectionTripExtraDetails', 'Trip Extra Details')}</div>
      <div className="divbox">
        <div className="vendor-container">
          <div className="form-group">
            <label>{tr('labelWhatsIncluded', 'What is Include')}</label>
            <div className="admin-lbl-boxv1">{ActivityData?.actWhatsIncluded}</div>
          </div>

          <div className="form-group">
            <label>{tr('labelTripDetails', 'Trip Details')}</label>
            <div className="admin-lbl-boxv1">{ActivityData?.actTripDetail}</div>
          </div>
        </div>
      </div>

      <div className="txtsubtitle">
        {tr('sectionTerms', 'Terms And Conditions')}
      </div>
      <div className="divbox">
        {/* // row start */}
        <div className="vendor-container">
          <div className="admin-lbl-boxv1">{ActivityData?.actAdminNotes}</div>
        </div>
        {/* // row end */}
      </div>
      <div className="button-container">
        <button
          type="button"
          className="admin-buttonv1"
          onClick={() => navigate('/vendordata/activityinfo/activity/list')}
        >
          {tr('btnReturn', 'Return')}
        </button>
      </div>
      <DspToastMessage message={toastMessage} type={toastType} />
    </div>
  )
}
export default Vendor
