// src/public/component/tripsummary.js
import React, { useEffect, useMemo, useRef, useState } from "react";
import icon5 from "../../assets/icon/icon5.png";
import FoodInfo from "../component/foodinfo";
import { API_BASE_URL } from "../../config";

// Apple Pay Method IDs (as MyFatoorah support says: unique ids)
const MF_APPLEPAY_VISA_MASTER_ID = 11; // Apple Pay (Visa/Master)
const MF_APPLEPAY_MADA_ID = 13; // Apple Pay (Mada)

// Other common method IDs you already use
const MF_VISA_MASTER_ID = 2;
const MF_STC_ID = 14;
const MF_MADA_ID = 6;

// ✅ Tiny Apple SVG (works on Windows + all browsers)
const AppleIcon = ({ size = 18 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 384 512"
    aria-hidden="true"
    focusable="false"
    style={{ display: "block" }}
  >
    <path
      fill="currentColor"
      d="M318.7 268.7c.3 34.9 15.6 61.9 46.3 80.5-5.9 17.1-13.6 33.4-23 48.9-12.8 21.1-26.1 42.2-46.9 42.6-20.3.4-26.8-12.1-49.9-12.1-23.1 0-30.3 11.8-49.4 12.5-20.1.8-35.4-20.2-48.3-41.2-26.3-42.7-46.4-120.7-19.4-173.5 13.4-26.3 37.3-42.9 63.4-43.3 19.8-.4 38.6 13.3 50.8 13.3 12.2 0 35.1-16.4 59.2-14 10.1.4 38.4 4.1 56.6 30.9-1.5.9-33.8 19.7-33.4 58.4zM259.4 74.8c10.7-13 17.9-31.2 15.9-49.8-15.4.6-34.1 10.3-45.1 23.2-9.9 11.5-18.5 29.8-16.2 47.4 17.2 1.3 34.7-8.7 45.4-20.8z"
    />
  </svg>
);

const TrupSummary = ({
  dict,
  priceTotal,
  grandTotalWithTax,
  validKidsCount,
  ActivityData,
  TripData,
  checkedFoodItems,
  handleCheckboxChange,
  foodQty,
  handleExtraQtyChange,
  lang,
  paymentAmount,
  apiBase, // passed from program.jsx
  onPaymentMethodSelect,
  onSubmit,
  tripPriceInclVat = 0,
  extraPriceInclVat = 0,

  // ✅ VAT display support - keep existing names, only add optional props
  tripVatAmount = null,
  extraVatAmount = null,
  totalVatAmount = null,

  selectedMethodId, // optional if passed (ignored safely)

  // ✅ FIX: support hidePaymentPicker from program.jsx
  hidePaymentPicker = false,
}) => {
  const isArabic = lang === "ar";

  const to2 = (v) => {
    const n = Number(v || 0);
    if (!Number.isFinite(n)) return "0.00";
    const scaled = Math.round((n + Number.EPSILON) * 100);
    return (scaled / 100).toFixed(2);
  };

  const hasAnyFood = useMemo(
    () => Array.isArray(ActivityData?.foodList) && ActivityData.foodList.length > 0,
    [ActivityData]
  );

  const basePerStudent = Number(tripPriceInclVat) || 0;
  const extraTotal = Number(extraPriceInclVat) || 0;
  const totalPayable = Number(grandTotalWithTax) || basePerStudent + extraTotal;

  const netForKids =
    validKidsCount > 0 ? basePerStudent * validKidsCount + extraTotal : totalPayable;

  // ✅ KEEP ORIGINAL VALUE: tripPriceInclVat / basePerStudent is still available above.
  // ✅ Display rule requested: Trip Price must be Net/Base price BEFORE VAT.
  //    Trip Price = Base Price - Total VAT, calculated below after VAT values are ready.
  const tripPriceDisplayRaw = basePerStudent;

  // --------------------------
  // ✅ VAT display helpers
  // Do not rename existing variables. These helpers only read the existing data/props.
  // Priority:
  // 1) Use optional values passed from parent if available.
  // 2) Read VAT amount fields from ActivityData / TripData / checked food items if available.
  // 3) If no VAT amount exists but VAT percentage exists, calculate VAT included inside the price.
  // --------------------------
  const toNum = (v) => {
    const n = Number(v || 0);
    return Number.isFinite(n) ? n : 0;
  };

  const firstNumber = (...values) => {
    for (const v of values) {
      const n = toNum(v);
      if (n > 0) return n;
    }
    return 0;
  };

  const getIncludedVatFromTotal = (amountWithVat, vatPercentage) => {
    const amount = toNum(amountWithVat);
    const pct = toNum(vatPercentage);
    if (amount <= 0 || pct <= 0) return 0;
    return amount - amount / (1 + pct / 100);
  };

  // ✅ Read VAT totals from ActivityData.priceList also.
  // Your API returns VAT inside priceList, not only at ActivityData top level.
  const priceListVatTotals = useMemo(() => {
    const list = Array.isArray(ActivityData?.priceList) ? ActivityData.priceList : [];

    return list.reduce(
      (acc, item) => {
        acc.actVat += toNum(item?.actPriceVatAmount);
        acc.herozVat += toNum(item?.HerozStudentPriceVatAmount);
        acc.schoolVat += toNum(item?.RequestSchoolPriceVatAmount ?? item?.SchoolPriceVatAmount);
        return acc;
      },
      { actVat: 0, herozVat: 0, schoolVat: 0 }
    );
  }, [ActivityData]);

  const activityPriceVatAmount = firstNumber(
    ActivityData?.actPriceVatAmount,
    ActivityData?.ActPriceVatAmount,
    ActivityData?.PriceVatAmount,
    ActivityData?.priceVatAmount,
    priceListVatTotals.actVat
  );

  const herozStudentPriceVatAmount = firstNumber(
    ActivityData?.HerozStudentPriceVatAmount,
    ActivityData?.herozStudentPriceVatAmount,
    ActivityData?.HerozPriceVatAmount,
    ActivityData?.herozPriceVatAmount,
    priceListVatTotals.herozVat
  );

  const schoolPriceVatAmount = firstNumber(
    ActivityData?.SchoolPriceVatAmount,
    ActivityData?.schoolPriceVatAmount,
    TripData?.SchoolPriceVatAmount,
    TripData?.schoolPriceVatAmount,
    priceListVatTotals.schoolVat
  );

  const tripVatFromFields = activityPriceVatAmount + herozStudentPriceVatAmount + schoolPriceVatAmount;

  const tripVatFromPercentage = getIncludedVatFromTotal(
    basePerStudent,
    firstNumber(
      ActivityData?.actPriceVatPercentage,
      ActivityData?.ActPriceVatPercentage,
      ActivityData?.VatPercentage,
      ActivityData?.vatPercentage,
      TripData?.actPriceVatPercentage,
      TripData?.vatPercentage
    )
  );

  const selectedFoodVatTotal = useMemo(() => {
    const selectedList = Array.isArray(checkedFoodItems) ? checkedFoodItems : [];
    const qtySource = foodQty || {};

    return selectedList.reduce((sum, item) => {
      if (!item) return sum;

      const itemId =
        item.FoodID ||
        item.foodID ||
        item.FoodId ||
        item.foodId ||
        item.id ||
        item._id ||
        item.foodid;

      const qty = Math.max(1, toNum(qtySource?.[itemId] || item.qty || item.Qty || item.quantity || 1));

      const directVat = firstNumber(
        item.foodVatAmount,
        item.FoodVatAmount,
        item.VatAmount,
        item.vatAmount,
        item.foodPriceVatAmount,
        item.FoodPriceVatAmount,
        item.ExtraVatAmount,
        item.extraVatAmount
      );

      if (directVat > 0) return sum + directVat * qty;

      const itemPriceInclVat = firstNumber(
        item.foodPriceInclVat,
        item.FoodPriceInclVat,
        item.PriceInclVat,
        item.priceInclVat,
        item.FoodPrice,
        item.foodPrice,
        item.Price,
        item.price
      );

      const itemVatPct = firstNumber(
        item.foodVatPercentage,
        item.FoodVatPercentage,
        item.VatPercentage,
        item.vatPercentage,
        item.foodPriceVatPercentage,
        item.FoodPriceVatPercentage
      );

      return sum + getIncludedVatFromTotal(itemPriceInclVat * qty, itemVatPct);
    }, 0);
  }, [checkedFoodItems, foodQty]);

  const tripVatDisplay =
    tripVatAmount !== null && tripVatAmount !== undefined
      ? toNum(tripVatAmount)
      : tripVatFromFields > 0
      ? tripVatFromFields
      : tripVatFromPercentage;

  const extraVatDisplay =
    extraVatAmount !== null && extraVatAmount !== undefined
      ? toNum(extraVatAmount)
      : selectedFoodVatTotal;

  const totalVatDisplay =
    totalVatAmount !== null && totalVatAmount !== undefined
      ? toNum(totalVatAmount)
      : tripVatDisplay * Math.max(1, toNum(validKidsCount) || 1) + extraVatDisplay;

  // Display trip price as-is (no VAT subtraction)
  const tripPriceDisplay = basePerStudent;
  // Single total payable = trip * kids + extras
  const totalPayableDisplay = netForKids;

  // --------------------------
  // ✅ Payment UI state
  // --------------------------
  const [loadingMethods, setLoadingMethods] = useState(false);
  const [methodsErr, setMethodsErr] = useState("");
  const [availableIds, setAvailableIds] = useState(new Set());
  const [selectedId, setSelectedId] = useState(null);

  const reqIdRef = useRef(0);

  const safeParse = async (r) => {
    const txt = await r.text();
    try {
      return JSON.parse(txt);
    } catch {
      return { raw: txt };
    }
  };

  // ✅ FIX: do NOT call initiate-payment when hidePaymentPicker is true
  useEffect(() => {
    if (hidePaymentPicker) {
      // optional: reset any prior state
      setLoadingMethods(false);
      setMethodsErr("");
      setAvailableIds(new Set());
      setSelectedId(null);
      return;
    }

    const run = async () => {
      setMethodsErr("");
      setLoadingMethods(true);
      const myReqId = ++reqIdRef.current;

      try {
        const r = await fetch(
          `${apiBase || API_BASE_URL}/myfatrooahdata/pay/initiate-payment`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              amount: Number(paymentAmount) || 0,
              currency: "SAR",
            }),
          }
        );

        const data = await safeParse(r);
        if (myReqId !== reqIdRef.current) return;

        if (!r.ok) {
          setMethodsErr(
            data?.Message ||
              data?.error?.Message ||
              (typeof data === "string" ? data : JSON.stringify(data)).slice(0, 500)
          );
          setAvailableIds(new Set());
          return;
        }

        const list = data?.Data?.PaymentMethods || [];
        const ids = new Set(
          list.map((m) => Number(m?.PaymentMethodId)).filter((x) => Number.isFinite(x))
        );
        setAvailableIds(ids);

        // ✅ default selection (prefer Mada -> Visa/Master -> STC)
        const defaultId =
          (ids.has(MF_MADA_ID) && MF_MADA_ID) ||
          (ids.has(MF_VISA_MASTER_ID) && MF_VISA_MASTER_ID) ||
          (ids.has(MF_STC_ID) && MF_STC_ID) ||
          null;

        if (defaultId != null) {
          setSelectedId(defaultId);
          onPaymentMethodSelect?.(defaultId, { PaymentMethodId: defaultId });
        }
      } catch (e) {
        if (myReqId !== reqIdRef.current) return;
        setMethodsErr(String(e));
        setAvailableIds(new Set());
      } finally {
        if (myReqId === reqIdRef.current) setLoadingMethods(false);
      }
    };

    run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paymentAmount, apiBase, hidePaymentPicker]);

  const selectMethod = (id) => {
    const nid = Number(id);
    if (!Number.isFinite(nid) || nid <= 0) return;
    setSelectedId(nid);
    onPaymentMethodSelect?.(nid, { PaymentMethodId: nid });
  };

  // ✅ Apple Pay radio logic:
  // select 13 if available else 11
  const selectApplePay = () => {
    const hasMada = availableIds.has(MF_APPLEPAY_MADA_ID);
    const hasVisa = availableIds.has(MF_APPLEPAY_VISA_MASTER_ID);

    if (hasMada) return selectMethod(MF_APPLEPAY_MADA_ID);
    if (hasVisa) return selectMethod(MF_APPLEPAY_VISA_MASTER_ID);

    setMethodsErr(isArabic ? "Apple Pay غير متاح حالياً." : "Apple Pay is not available right now.");
  };

  const showMethod = (id) => availableIds.size === 0 || availableIds.has(id);

  const isApplePaySelected =
    selectedId === MF_APPLEPAY_MADA_ID || selectedId === MF_APPLEPAY_VISA_MASTER_ID;

  const canShowApplePay =
    availableIds.size === 0 ||
    availableIds.has(MF_APPLEPAY_MADA_ID) ||
    availableIds.has(MF_APPLEPAY_VISA_MASTER_ID);

  return (
    <div className="card pricing">
      <h3 className="card-title trip-gradient-color fontsize40">{dict.tripsPricing}</h3>

      {/* Trip Price (ONE amount INCLUDING VAT per student) */}
      <div className="price-row">
        <span className="price-label fontsize20">{dict.baseTripCost}</span>
        <span className="price-value fontsize20">
          {to2(tripPriceDisplay)} <img src={icon5} alt="HEROZ" />
        </span>
      </div>

      <div className="divider" />

      {/* Food block */}
      {hasAnyFood && (
        <>
          <div className="food-wrap">
            <FoodInfo
              ActivityData={ActivityData}
              checkedFoodItems={checkedFoodItems}
              handleCheckboxChange={handleCheckboxChange}
              schoolReqFoodPrice={TripData?.schoolreqfoodprice ?? []}
              foodQty={foodQty}
              onQtyChange={handleExtraQtyChange}
              lang={lang}
            />
          </div>

          <div className="divider" />
        </>
      )}

      {/* Single Total Payable */}
      <div className="summary-row total trip-gradient-color">
        <span>
          {dict.totalPayable || (isArabic ? "إجمالي المبلغ المستحق" : "Total Payable")}
        </span>
        <span>
          {to2(totalPayableDisplay)} <img src={icon5} alt="HEROZ" />
        </span>
      </div>

      <div className="divider" />

      {/* ✅ Payment methods (HIDDEN when using embedded) */}
      {!hidePaymentPicker && (
        <div style={{ marginTop: 12 }}>
          <div style={{ fontWeight: 700, marginBottom: 8 }}>
            {dict.ar_choose_method || (isArabic ? "اختر طريقة الدفع:" : "Choose payment method:")}
            <span style={{ color: "red", fontSize: 22, marginInlineStart: 6 }}>*</span>
          </div>

          {loadingMethods && (
            <div style={{ padding: 10, borderRadius: 8, border: "1px solid #ddd" }}>
              {dict.loadingPaymentMethods || "Loading payment methods…"}
            </div>
          )}

          <div style={{ display: "grid", gap: 8 }}>
            {canShowApplePay && (
              <label
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "12px 14px",
                  borderRadius: 10,
                  border: isApplePaySelected ? "2px solid #1976d2" : "1px solid #000",
                  cursor: loadingMethods ? "not-allowed" : "pointer",
                  backgroundColor: "#000",
                  color: "#fff",
                  userSelect: "none",
                }}
                onClick={(e) => {
                  if (loadingMethods) return;
                  if (e.target?.tagName?.toLowerCase() !== "input") selectApplePay();
                }}
              >
                <input
                  type="radio"
                  name="mf-method-simple"
                  checked={isApplePaySelected}
                  onChange={selectApplePay}
                  disabled={loadingMethods}
                  style={{ width: 18, height: 18, accentColor: "#fff" }}
                />

                <span
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 8,
                    color: "#fff",
                    fontWeight: 900,
                    fontSize: 16,
                  }}
                >
                  <span style={{ color: "#fff" }}>
                    <AppleIcon size={18} />
                  </span>
                  <span style={{ color: "#fff" }}>Pay</span>
                </span>

                <span style={{ marginInlineStart: "auto", fontWeight: 800, color: "#fff" }}>
                  {isApplePaySelected ? "✓" : ""}
                </span>
              </label>
            )}

            {showMethod(MF_MADA_ID) && (
              <label
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: 10,
                  borderRadius: 8,
                  border: selectedId === MF_MADA_ID ? "2px solid #1976d2" : "1px solid #ccc",
                  cursor: "pointer",
                }}
              >
                <input
                  type="radio"
                  name="mf-method-simple"
                  checked={selectedId === MF_MADA_ID}
                  onChange={() => selectMethod(MF_MADA_ID)}
                />
                <span style={{ fontWeight: 700 }}>{isArabic ? "مدى" : "MADA"}</span>
              </label>
            )}

            {showMethod(MF_VISA_MASTER_ID) && (
              <label
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: 10,
                  borderRadius: 8,
                  border: selectedId === MF_VISA_MASTER_ID ? "2px solid #1976d2" : "1px solid #ccc",
                  cursor: "pointer",
                }}
              >
                <input
                  type="radio"
                  name="mf-method-simple"
                  checked={selectedId === MF_VISA_MASTER_ID}
                  onChange={() => selectMethod(MF_VISA_MASTER_ID)}
                />
                <span style={{ fontWeight: 700 }}>{isArabic ? "فيزا / ماستر" : "VISA / MasterCard"}</span>
              </label>
            )}

            {showMethod(MF_STC_ID) && (
              <label
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: 10,
                  borderRadius: 8,
                  border: selectedId === MF_STC_ID ? "2px solid #1976d2" : "1px solid #ccc",
                  cursor: "pointer",
                }}
              >
                <input
                  type="radio"
                  name="mf-method-simple"
                  checked={selectedId === MF_STC_ID}
                  onChange={() => selectMethod(MF_STC_ID)}
                />
                <span style={{ fontWeight: 700 }}>{isArabic ? "STC Pay" : "STC Pay"}</span>
              </label>
            )}
          </div>

          {!!methodsErr && (
            <div
              style={{
                marginTop: 10,
                background: "#ffe6e6",
                border: "1px solid #f5a9a9",
                color: "#a40000",
                padding: 10,
                borderRadius: 8,
              }}
            >
              <strong>{dict.errorTitle || "Error"}:</strong> {methodsErr}
            </div>
          )}
        </div>
      )}

      {/* ✅ Terms checkbox MUST remain for program.jsx validation */}
      <div
        style={{
          marginTop: 12,
          padding: 10,
          borderRadius: 8,
          border: "1px solid rgba(255, 221, 87, 0.8)",
          backgroundColor: "rgba(255, 249, 196, 0.5)",
          display: "flex",
          alignItems: "center",
          gap: 8,
        }}
      >
        <span style={{ color: "red", fontSize: 22 }}>*</span>
        <input type="checkbox" id="termsAgree" style={{ width: 18, height: 18 }} />
        <label htmlFor="termsAgree" style={{ margin: 0, cursor: "pointer" }}>
          {dict.ar_terms_agree ||
            (isArabic ? "أوافق على الشروط والأحكام" : "I agree to terms & conditions")}
        </label>
      </div>

      <div className="divider" />

      {/* Continue button */}
      <div className="payment-group">
        <button className="btn-primary" onClick={onSubmit}>
          {dict.continueToPayment}
        </button>
      </div>
    </div>
  );
};

export default TrupSummary;