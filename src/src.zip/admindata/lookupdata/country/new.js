import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { API_BASE_URL } from '../../../config'
import { checkLogin } from '../../../utils/auth'
import '../../../scss/toast.css'
import { DspToastMessage, getAuthHeaders, IsAdminLoginIsValid } from '../../../utils/operation'

const AddCountryForm = () => {
  const navigate = useNavigate()

  const [EnCountryName, setEnCountryName] = useState('')
  const [ArCountryName, setArCountryName] = useState('')
  const [IsDataStatus, setIsDataStatus] = useState(true)
  const [loading, setLoading] = useState(false)
  const [toastMessage, setToastMessage] = useState('')
  const [toastType, setToastType] = useState('info')

  useEffect(() => {
    checkLogin(navigate)
  }, [navigate])

  // 🔐 Admin login validation
  useEffect(() => {
    IsAdminLoginIsValid() // will redirect to BaseURL if token/usertype invalid
  }, [])

  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(''), 2000)
      return () => clearTimeout(timer)
    }
  }, [toastMessage])

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!EnCountryName || !ArCountryName) {
      setToastMessage('Please fill in all required fields.')
      setToastType('fail')
      return
    }

    setLoading(true)
    setToastMessage('')

    try {
      const response = await fetch(`${API_BASE_URL}/lookupdata/Country/createCountry`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({
          EnCountryName,
          ArCountryName,
          IsDataStatus: 1,
          CreatedBy: 'USER', // Ideally get from auth context
          ModifyBy: 'USER',
        }),
      })

      if (!response.ok) throw new Error(`HTTP error: ${response.status}`)

      await response.json()
      setToastMessage('Country added successfully!')
      setToastType('success')

      setTimeout(() => navigate('/admindata/country/list'), 2000)
    } catch (err) {
      console.error('Error adding Country:', err)
      setToastMessage('Failed to add Country.')
      setToastType('fail')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="form-container">
      <div className="page-title">
        <h3 style={{ margin: 0 }}>Add Country</h3>
        <button
          type="button"
          onClick={() => navigate('/admindata/country/list')}
          className="admin-buttonv1"
        >
          Return
        </button>
      </div>

      <div className="form-group">
        <label>English Country Name</label>
        <input
          className="admin-txt-box"
          type="text"
          value={EnCountryName}
          onChange={(e) => setEnCountryName(e.target.value)}
          placeholder="Enter English Country Name"
          required
        />
      </div>

      <div className="form-group">
        <label>Arabic Country Name</label>
        <input
          className="admin-txt-box"
          type="text"
          value={ArCountryName}
          onChange={(e) => setArCountryName(e.target.value)}
          placeholder="Enter Arabic Country Name"
          required
        />
      </div>

      <div className="submit-container custom-top-5">
        <button type="submit" className="admin-buttonv1" disabled={loading}>
          {loading ? 'Saving...' : 'Submit'}
        </button>
      </div>

      <DspToastMessage message={toastMessage} type={toastType} />
    </form>
  )
}

export default AddCountryForm
